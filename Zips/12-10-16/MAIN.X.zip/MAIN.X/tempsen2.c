#include <p18f452.h>
#include <delays.h>
#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include <math.h>
#include "xlcd_lab1.h"

#pragma config OSC = HS
#pragma config WDT = OFF //Disable watchdog timer
#pragma config LVP = OFF //Disable low voltage programming

 char array[16] = {NULL};
 char array2[16] = {NULL};
 unsigned char get[10], temp_msb, temp_lsb, temp_int, count;
 int temp_frac, temp_hold;
 int temp_frac_l, work;
 
 
 

void DelayFor18TCY(void)
{
    Delay10TCYx(2);
    return;
}

void DelayPORXLCD (void)
{
    Delay1KTCYx(15); // Delay of 15ms, Cycles = (15ms * 4MHz) / 4 = 15,0000
    return;
}

void DelayXLCD (void)
{
    Delay1KTCYx(5); // Delay of 5ms, Cycles = (5ms * 4MHz) / 4 = 5000
    return;
}

void get_temp(char temp_msb, char temp_lsb)
{
    
    temp_frac = 0;
    //Get the decimal number
    temp_frac = (temp_lsb & 0x01) * (625);
    temp_frac = temp_frac + ((temp_lsb & 0b00000010)>>1)* (1250);
    temp_frac = temp_frac + ((temp_lsb & 0b00000100)>>2)*(2500);
    temp_frac = temp_frac + ((temp_lsb & 0b00001000)>>3)*(5000);
    temp_hold =temp_frac;
    count =0;
    while ((temp_hold/1000)>0){
        count = count + 1;
        temp_hold = temp_hold - 1000;
    }
    if ((temp_frac-(count*1000))>500){
        count = count +1;
    }
    temp_frac = count;
    //Get the whole number
    temp_lsb = (temp_lsb >> 4); // shift to get whole degre
    temp_msb = (temp_msb << 4);
    temp_int = (temp_lsb + temp_msb);
    return;
}

void main(void)
{
    get[0] = 0b11010000;
    get[1] = 0b00000111;
    if (get[1] <= 0x80){
        temp_msb = get[1];
        temp_lsb = get[0];  
        get_temp(temp_msb, temp_lsb);
        
        OpenXLCD(FOUR_BIT & LINES_5X7);
        while(BusyXLCD());
        SetDDRamAddr(0x00);
        WriteCmdXLCD(SHIFT_DISP_LEFT);
        sprintf(array,"%3d.%1d C", temp_int, temp_frac);
        putsXLCD(array); //show in LCD  
   
    }else{
        work = get[1];
        work = work<<8;
        work = work+get[0];
        work = (~work)+1; //
        temp_lsb = (work & 0xFF);
        temp_msb = (work >> 8) & 0xFF;
        get_temp(temp_msb, temp_lsb);
        
        
        OpenXLCD(FOUR_BIT & LINES_5X7);
        while(BusyXLCD());
        SetDDRamAddr(0x00);
        WriteCmdXLCD(SHIFT_DISP_LEFT);
        sprintf(array,"-%3d.%1d �C", temp_int, temp_frac);
        putsXLCD(array); //show in LCD       
    }
    
    Sleep();
}
