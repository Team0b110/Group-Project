#include <p18f452.h>
#include <delays.h>
#include <p18cxxx.h>

#pragma config OSC = HS
#pragma config WDT = OFF
#pragma config LVP = OFF

//Reset
unsigned char reset_func(void)
{
    unsigned char pres;
    TRISAbits.RA4 = 0;
  	LATAbits.LATA4 = 0; //reset pulse by pulling the 1-Wire bus low for a minimum of 480�s
    Delay1TCYx(480); //1TCY is 1�s 
    TRISAbits.RA4 = 1;
    Delay1TCYx(70); //DS1822 waits 15�s to 60�s and then transmits a presence pulse by pulling the 1-Wire bus low for 60�s to 240�s.
    pres = LATAbits.LATA4;
    Delay1TCYx(230);
    return(pres);  
}

//Write Bit
void write_abit(char bitval)
{
    TRISAbits.RA4 = 0;
  	LATAbits.LATA4 = 0; // pull DQ low to start timeslot
	if(bitval==1) LATAbits.LATA4 = 1; // return DQ high if write 1
	Delay1TCYx(104); // hold value for remainder of timeslot
	LATAbits.LATA4 =  1;
}//  delay = 104us

//Write Byte
void write_abyte(char val)
{
	unsigned char i;
	unsigned char temp;
	for (i=0; i<8; i++) // writes byte, one bit at a time
{
	temp = val>>i; // shifts val right 'i' spaces
	temp &= 0x01; // copy that bit to temp
	write_abit(temp); // write bit in temp into
}
Delay1TCYx(104);
} 

//Read Bit
unsigned char read_abit(void)
{
	unsigned char i;
	LATAbits.LATA4 = 0; // pull DQ low to start timeslot
	LATAbits.LATA4 = 1; // then return high
	for (i=0; i<3; i++); // delay 15us from start of timeslot
{
	TRISAbits.RA4 = 0;
	return(LATAbits.LATA4); // return value of DQ line
}
}

//Read Byte
unsigned char read_byte(void)
{
unsigned char i;
unsigned char value = 0;
for (i=0;i<8;i++)
{
if(read_abit()) value|=0x01<<i; // reads byte in, one byte at a time and then
// shifts it left
Delay1TCYx(125); // wait for rest of timeslot
}
return(value);
}

//Reading the Scratch Pad memoy
void Read_ScratchPad(void)
{
int j;
char pad[10];
printf("\nReading ScratchPad Data\n");
write_abyte(0xBE);
for (j=0;j<9;j++){pad[j]=read_byte();}
printf("\n ScratchPAD DATA =
%X%X%X%X%X%X\n",pad[8],pad[7],pad[6],pad[5],pad[4],pad[3],pad[2],pad[1],pad[0]);
}

//The "Read ROM" command is used to find the 64-bit ROM code when only a single device is on the net
void Read_ROMCode(void)
{
int n;
char dat[9];
printf("\nReading ROM Code\n");
reset_func();
write_abyte(0x33);
for (n=0;n<8;n++){dat[n]=read_byte();}
printf("\n ROM Code = %X%X%X%X\n",dat[7],dat[6],dat[5],dat[4],dat[3],dat[2],dat[1],dat[0]);
}

//Reading Temperature
void Read_Temperature(void)
{
char get[10];
char temp_lsb,temp_msb;
int k;
char temp_f,temp_c;
reset_func();
write_abyte(0xCC); //Skip ROM
write_abyte(0x44); // Start Conversion
Delay1TCYx(104);
reset_func();
write_abyte(0xCC); // Skip ROM
write_abyte(0xBE); // Read Scratch Pad
for (k=0;k<9;k++){get[k]=read_abyte();}
printf("\n ScratchPAD DATA =
%X%X%X%X%X\n",get[8],get[7],get[6],get[5],get[4],get[3],get[2],get[1],get[0]);
temp_msb = get[1]; // Sign byte + lsbit
temp_lsb = get[0]; // Temp data plus lsb
if (temp_msb <= 0x80){temp_lsb = (temp_lsb/2);} // shift to get whole degree
temp_msb = temp_msb & 0x80; // mask all but the sign bit
if (temp_msb >= 0x80) {temp_lsb = (~temp_lsb)+1;} // twos complement
if (temp_msb >= 0x80) {temp_lsb = (temp_lsb/2);}// shift to get whole degree
if (temp_msb >= 0x80) {temp_lsb = ((-1)*temp_lsb);} // add sign bit
printf( "\nTempC= %d degrees C\n", (int)temp_lsb ); // print temp. C
temp_c = temp_lsb; // ready for conversion to Fahrenheit
//temp_f = (((int)temp_c)* 9)/5 + 32;
//printf( "\nTempF= %d degrees F\n", (int)temp_f ); // print temp. F
}

void main(void){
    TRISAbits.RA4 = 0;
 
    LATAbits.LATA4 = 0;
 
     LATAbits.LATA4 = 1;
    Delay1KTCYx(1);
    LATAbits.LATA4 = 0;

 OutputToRegister(0x00);
 Nop();
 OutputToRegister(0xAA);
  Nop();
OutputToRegister(0xFF);
 Nop();
 OutputToRegister(0x80);
 Nop();
}